function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(27, 50, 90);
  
  fill(250, 250, 250);
  ellipse(mouseX, mouseY, 150, 150);
  
  fill(250, 250, 0);
  ellipse(mouseX, mouseY, 50, 50);
}
