
let a = 10;
let colo = 10;

function setup() {
  createCanvas(500, 500);
}

function draw() {
  background(150, 50, 50);
  fill(0, colo, 0);
  ellipse(250, 250, a, a);

  // Igual comportamiento que en Processing: si una tecla está presionada
  // y es 'w' o 's', modificamos 'a' y 'colo'.
  if (keyIsPressed) {
    // en p5.js "key" es una string; comprobamos la minúscula
    if (key === 'w') {
      a = a + 10;
      colo = colo + 10;
    } else if (key === 's') {
      a = a - 10;
      colo = colo - 10;
    }
  }
}